<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Categories;
use App\Models\ProductTypes;
use App\Models\Product;
use App\Models\Comment;

use Cart;
use Auth;
class HomeController extends Controller
{
    public function __construct(){
    	$category = Categories::where('status',1)->get();
    	$producttype = ProductTypes::where('status',1)->get();
        view()->share(['category' => $category,'producttype' => $producttype]);
    }

    public function index(){
        $product1 = Product::where('status',1)->where('idProductType',1)->get();
        $product2 = Product::where('status',1)->where('idProductType',2)->get();
		return view('client.pages.index',['prosamsung' => $product1, 'proTaiNghe' => $product2]);
	}

    public function getDetail($slug) {
        $productID = Product::where('slug', $slug)->first();
        $productDetail = Product::where('slug', $slug)->first();
        $idProType = ProductTypes::where('slug', $slug)->first();
        
        $comments = Product::find($productID->id)->comments;
        if ($productDetail) {
            return view('client.pages.detail', ['product' => $productDetail,'comments'=>$comments]);
        }
        else if($idProType) {
            $productByProdType = Product::where('idProductType', $idProType->id)->get();
            return view('client.pages.detail_protype', ['product' => $productByProdType, 'producttype' => $idProType,'comments'=>$comments]);
        }
    }
}
